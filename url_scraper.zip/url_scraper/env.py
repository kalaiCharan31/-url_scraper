# app/env.py
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Database URL
DATABASE_URL = os.environ.get("DATABASE_URL", "postgresql://kalaicharan:123456@db:5432/url_scraper")
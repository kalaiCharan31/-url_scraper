from celery import Celery
from app.utils import scrape_url
from app.database import SessionLocal
from app.models import URLMetadata

celery = Celery(__name__, broker='redis://localhost:6379/0')

@celery.task
def scrape_and_store(url):
    title, description, keywords = scrape_url(url)
    db = SessionLocal()
    metadata = URLMetadata(url=url, title=title, description=description, keywords=keywords)
    db.add(metadata)
   
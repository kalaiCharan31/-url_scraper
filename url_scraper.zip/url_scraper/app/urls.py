# app/routers/urls.py
from fastapi import APIRouter, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.models import URLMetadata
from app.schemas import URLMetadataCreate, URLMetadataResponse
from app.tasks import scrape_and_store
import pandas as pd
import uuid

router = APIRouter()

# Dependency to get the database session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/upload")
async def upload_csv(file: UploadFile = File(...), db: Session = next(get_db())):
    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="Invalid file type. Please upload a CSV file.")

    # Read the CSV file
    contents = await file.read()
    df = pd.read_csv(pd.compat.StringIO(contents.decode('utf-8')))

    if 'url' not in df.columns:
        raise HTTPException(status_code=400, detail="CSV must contain a 'url' column.")

    # Process each URL
    for url in df['url']:
        task_id = str(uuid.uuid4())  # Generate a unique task ID
        scrape_and_store.delay(url)  # Call the Celery task asynchronously

    return {"message": "URLs are being processed", "task_id": task_id}

@router.get("/status/{task_id}")
async def get_status(task_id: str):
    # Here you would implement logic to check the status of the task
    # For now, we will return a placeholder response
    return {"task_id": task_id, "status": "Processing"}

@router.get("/results/{task_id}", response_model=list[URLMetadataResponse])
async def get_results(task_id: str, db: Session = next(get_db())):
    # Fetch results from the database based on the task_id
    results = db.query(URLMetadata).filter(URLMetadata.id == task_id).all()
    if not results:
        raise HTTPException(status_code=404, detail="No results found for this task ID.")
    return results
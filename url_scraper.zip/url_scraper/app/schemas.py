from pydantic import BaseModel

class URLMetadataCreate(BaseModel):
    url: str

class URLMetadataResponse(BaseModel):
    id: int
    url: str
    title: str
    description: str
    keywords: str

    class Config:
        orm_mode = True
# database.py
import sqlite3

def create_database():
    """Creates a new SQLite database."""
    conn = sqlite3.connect('urls.db')  # Create or connect to the database
    cursor = conn.cursor()

    # Create the table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS urls (
            id INTEGER PRIMARY KEY,
            url TEXT UNIQUE NOT NULL
        )
    ''')

    conn.commit()
    conn.close()

# Your additional database interaction functions can be added here
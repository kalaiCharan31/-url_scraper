from fastapi import FastAPI
from app import urls
from app.database import engine
from app.models import Base

app = FastAPI()

# Create database tables
Base.metadata.create_all(bind=engine)

app.include_router(urls.router)